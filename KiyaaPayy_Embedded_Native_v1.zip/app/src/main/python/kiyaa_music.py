"""
KiyaaPayy embedded provider.
Adapted from the user's original Flask server.py:
- ytmusicapi search(filter="songs")
- ytmusicapi get_lyrics(video_id) (best-effort; API may require a lyrics browse id)
- yt-dlp extract_info(download=False) to obtain a direct audio URL
All calls execute inside the Android app via Chaquopy; no Flask server/VPS/Termux.
"""
import json
import re
from ytmusicapi import YTMusic
import yt_dlp

_client = None

def client():
    global _client
    if _client is None:
        _client = YTMusic()
    return _client

def search(query):
    q = (query or "").strip()
    if not q:
        return "[]"
    if len(q) > 160:
        raise ValueError("Query terlalu panjang")
    results = client().search(q, filter="songs", limit=25)
    songs = []
    for item in results:
        artists = ", ".join(a.get("name", "") for a in item.get("artists", []) if a.get("name"))
        thumbs = item.get("thumbnails") or []
        songs.append({
            "videoId": item.get("videoId"),
            "title": item.get("title") or "Tanpa judul",
            "artists": artists or "Artis tidak diketahui",
            "album": (item.get("album") or {}).get("name", ""),
            "duration": item.get("duration") or "",
            "thumbnail": thumbs[-1].get("url", "") if thumbs else ""
        })
    return json.dumps(songs, ensure_ascii=False)

def stream(video_id):
    if not re.fullmatch(r"[A-Za-z0-9_-]{11}", video_id or ""):
        raise ValueError("ID video tidak valid")
    url = "https://www.youtube.com/watch?v=" + video_id
    opts = {
        "format": "bestaudio[ext=m4a]/bestaudio/best",
        "quiet": True,
        "no_warnings": True,
        "noplaylist": True,
        "skip_download": True,
        "extract_flat": False,
        "cachedir": False,
    }
    with yt_dlp.YoutubeDL(opts) as ydl:
        info = ydl.extract_info(url, download=False)
    if not info:
        raise RuntimeError("Stream tidak tersedia")
    # Prefer requested format URL when yt-dlp returns a merged entry.
    direct = info.get("url")
    if not direct and info.get("requested_formats"):
        direct = next((f.get("url") for f in info["requested_formats"] if f.get("url")), None)
    if not direct:
        raise RuntimeError("URL audio tidak ditemukan")
    return direct

def lyrics(video_id):
    # The original server.py calls get_lyrics(video_id). Keep that behavior,
    # but report unavailable cleanly because some ytmusicapi versions require
    # a lyrics browseId rather than a YouTube videoId.
    try:
        data = client().get_lyrics(video_id)
        return (data or {}).get("lyrics") or "Lirik tidak tersedia untuk lagu ini."
    except Exception:
        return "Lirik tidak tersedia untuk lagu ini."
