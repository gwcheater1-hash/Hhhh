package com.kiyaapay

import android.content.ComponentName
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.lifecycleScope
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.MoreExecutors
import kotlinx.coroutines.launch
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.concurrent.ExecutionException

private val Ink = Color(0xFF090B12)
private val Panel = Color(0xFF191C27)
private val Purple = Color(0xFFCBB6FF)
private val Muted = Color(0xFF9A9CAD)

class MainActivity : ComponentActivity() {
    private lateinit var repo: MusicRepository
    private var controller by mutableStateOf<MediaController?>(null)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        repo = MusicRepository(this)
        val token = SessionToken(this, ComponentName(this, PlaybackService::class.java))
        val future = MediaController.Builder(this, token).buildAsync()
        future.addListener({ try { controller = future.get() } catch (_: Exception) {} }, MoreExecutors.directExecutor())

        setContent {
            MaterialTheme(colorScheme = darkColorScheme(
                background = Ink, surface = Panel, primary = Purple,
                onBackground = Color(0xFFF5F4FA), onSurface = Color(0xFFF5F4FA)
            )) {
                KiyaaApp(repo, controller, onPlay = { song -> playSong(song) })
            }
        }
    }

    private fun playSong(song: Song) {
        lifecycleScope.launch {
            try {
                val url = repo.stream(song.videoId)
                val c = controller ?: return@launch
                val metadata = MediaMetadata.Builder()
                    .setTitle(song.title).setArtist(song.artists)
                    .setAlbumTitle(song.album).setArtworkUri(
                        song.thumbnail.takeIf { it.startsWith("https://") }?.let(android.net.Uri::parse)
                    ).build()
                c.setMediaItem(MediaItem.Builder().setUri(url).setMediaMetadata(metadata).build())
                c.prepare()
                c.play()
            } catch (e: Exception) {
                android.widget.Toast.makeText(this@MainActivity, "Gagal memuat stream: ${e.message}", android.widget.Toast.LENGTH_LONG).show()
            }
        }
    }
}

@Composable
private fun KiyaaApp(repo: MusicRepository, player: MediaController?, onPlay: (Song) -> Unit) {
    var query by remember { mutableStateOf("") }
    var songs by remember { mutableStateOf(emptyList<Song>()) }
    var liked by remember { mutableStateOf(emptyList<Song>()) }
    var history by remember { mutableStateOf(emptyList<Song>()) }
    var playlists by remember { mutableStateOf(mapOf<String, List<Song>>()) }
    var current by remember { mutableStateOf<Song?>(null) }
    var lyrics by remember { mutableStateOf("") }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf("") }
    var tab by remember { mutableStateOf("Beranda") }
    var showLyrics by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    LaunchedEffect(player?.currentMediaItemIndex, player?.isPlaying) {
        val p = player
        if (p != null) {
            while (true) {
                val md = p.currentMediaMetadata
                if (md.title != null) current = Song(
                    videoId = "", title = md.title.toString(),
                    artists = md.artist?.toString() ?: ""
                )
                kotlinx.coroutines.delay(700)
            }
        }
    }

    Column(Modifier.fillMaxSize().background(Ink)) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 18.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("KiyaaPayy", color = Purple, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.ExtraBold)
                Text("ruang musikmu", color = Muted, style = MaterialTheme.typography.labelSmall)
            }
            Icon(Icons.Default.GraphicEq, contentDescription = null, tint = Purple)
        }
        Row(Modifier.fillMaxWidth().padding(horizontal = 14.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("Beranda", "Cari", "Favorit", "Koleksi").forEach { label ->
                FilterChip(selected = tab == label, onClick = { tab = label }, label = { Text(label) })
            }
        }
        when (tab) {
            "Cari" -> {
                Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(query, { query = it }, Modifier.weight(1f), singleLine = true, placeholder = { Text("Cari lagu atau artis") })
                    IconButton(onClick = {
                        if (query.isNotBlank()) scope.launch {
                            loading = true; error = ""
                            try { songs = repo.search(query) } catch (e: Exception) { error = e.message ?: "Pencarian gagal" }
                            loading = false
                        }
                    }) { Icon(Icons.Default.Search, contentDescription = "Cari", tint = Purple) }
                }
                if (loading) LinearProgressIndicator(Modifier.fillMaxWidth().padding(horizontal = 16.dp))
                if (error.isNotBlank()) Text(error, color = Color(0xFFFF9AA8), modifier = Modifier.padding(16.dp))
                SongList(songs, liked, onPlay, onLike = { s -> liked = if (liked.any { it.videoId == s.videoId }) liked.filterNot { it.videoId == s.videoId } else listOf(s) + liked })
            }
            "Favorit" -> SongList(liked, liked, onPlay, onLike = { s -> liked = liked.filterNot { it.videoId == s.videoId } })
            "Koleksi" -> {
                Column(Modifier.padding(18.dp)) {
                    Text("Playlist lokal", style = MaterialTheme.typography.titleLarge)
                    Text("Playlist tersimpan selama aplikasi berjalan pada versi awal ini.", color = Muted)
                    Button(onClick = {
                        val name = "Playlist ${playlists.size + 1}"
                        playlists = playlists + (name to emptyList())
                    }) { Text("Buat playlist") }
                    playlists.forEach { (name, list) -> Text("$name · ${list.size} lagu", Modifier.padding(8.dp)) }
                }
            }
            else -> {
                Column(Modifier.fillMaxWidth().padding(20.dp)) {
                    Text("Temukan musik yang kamu suka.", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                    Text("Cari lagu dari katalog YouTube Music.", color = Muted, modifier = Modifier.padding(top = 8.dp))
                    Button(onClick = { tab = "Cari" }, modifier = Modifier.padding(top = 16.dp)) { Text("Mulai mencari") }
                    if (history.isNotEmpty()) {
                        Text("Baru diputar", style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(top = 24.dp))
                        SongList(history, liked, onPlay, onLike = { s -> liked = listOf(s) + liked })
                    }
                }
            }
        }
        Spacer(Modifier.weight(1f))
        if (showLyrics) {
            Surface(color = Panel, modifier = Modifier.fillMaxWidth().heightIn(max = 180.dp)) {
                Column(Modifier.padding(16.dp)) {
                    Text("Lirik", color = Purple, fontWeight = FontWeight.Bold)
                    Text(lyrics.ifBlank { "Lirik belum dimuat." }, color = Color.White)
                }
            }
        }
        Surface(color = Panel, tonalElevation = 5.dp) {
            Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(current?.title ?: "Belum ada lagu diputar", maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold)
                        Text(current?.artists ?: "Pilih lagu untuk mulai", color = Muted, style = MaterialTheme.typography.labelSmall)
                    }
                    IconButton(onClick = {
                        showLyrics = !showLyrics
                        val id = songs.firstOrNull { it.title == current?.title }?.videoId
                        if (id != null) scope.launch { lyrics = try { repo.lyrics(id) } catch (_: Exception) { "Lirik tidak tersedia." } }
                    }) { Icon(Icons.Default.Lyrics, contentDescription = "Lirik", tint = Purple) }
                    IconButton(onClick = { player?.seekToPreviousMediaItem() }) { Icon(Icons.Default.SkipPrevious, contentDescription = "Sebelumnya") }
                    IconButton(onClick = { if (player?.isPlaying == true) player.pause() else player?.play() }) {
                        Icon(if (player?.isPlaying == true) Icons.Default.Pause else Icons.Default.PlayArrow, contentDescription = "Putar/Jeda", tint = Purple)
                    }
                    IconButton(onClick = { player?.seekToNextMediaItem() }) { Icon(Icons.Default.SkipNext, contentDescription = "Berikutnya") }
                }
                if (player != null) {
                    Slider(value = if (player.duration > 0) (player.currentPosition.toFloat() / player.duration).coerceIn(0f, 1f) else 0f,
                        onValueChange = { if (player.duration > 0) player.seekTo((player.duration * it).toLong()) })
                }
            }
        }
    }
}

@Composable
private fun SongList(items: List<Song>, liked: List<Song>, onPlay: (Song) -> Unit, onLike: (Song) -> Unit) {
    LazyColumn(Modifier.fillMaxWidth().padding(horizontal = 12.dp)) {
        items(items, key = { it.videoId }) { song ->
            Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).clickable { onPlay(song) }.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                Surface(color = Color(0xFF343047), shape = RoundedCornerShape(10.dp), modifier = Modifier.size(46.dp)) {
                    Box(contentAlignment = Alignment.Center) { Icon(Icons.Default.MusicNote, contentDescription = null, tint = Purple) }
                }
                Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                    Text(song.title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold)
                    Text(song.artists, maxLines = 1, overflow = TextOverflow.Ellipsis, color = Muted, style = MaterialTheme.typography.labelSmall)
                }
                IconButton(onClick = { onLike(song) }) {
                    Icon(if (liked.any { it.videoId == song.videoId }) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                        contentDescription = "Favorit", tint = Purple)
                }
            }
        }
    }
}
