package com.kiyaapay

import android.content.Context
import com.chaquo.python.Python
import com.chaquo.python.android.AndroidPlatform
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class MusicRepository(private val context: Context) {
    private val gson = Gson()
    private fun module() = if (!Python.isStarted()) {
        Python.start(AndroidPlatform(context))
        Python.getInstance().getModule("kiyaa_music")
    } else Python.getInstance().getModule("kiyaa_music")

    suspend fun search(query: String): List<Song> = withContext(Dispatchers.IO) {
        val raw = module().callAttr("search", query).toString()
        val type = object : TypeToken<List<Song>>() {}.type
        gson.fromJson<List<Song>>(raw, type) ?: emptyList()
    }

    suspend fun stream(videoId: String): String = withContext(Dispatchers.IO) {
        module().callAttr("stream", videoId).toString()
    }

    suspend fun lyrics(videoId: String): String = withContext(Dispatchers.IO) {
        module().callAttr("lyrics", videoId).toString()
    }
}
