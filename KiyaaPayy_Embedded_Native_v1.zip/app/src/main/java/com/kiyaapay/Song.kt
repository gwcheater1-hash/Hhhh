package com.kiyaapay

data class Song(
    val videoId: String,
    val title: String,
    val artists: String,
    val album: String = "",
    val duration: String = "",
    val thumbnail: String = ""
)
