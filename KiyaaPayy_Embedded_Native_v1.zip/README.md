# KiyaaPayy — Native Android, embedded provider

This project is a native Kotlin + Jetpack Compose Android app. It is **not WebView** and does not need Flask, Termux, a VPS, or a separately hosted API.

## Embedded music provider
The original `server.py` provider logic is adapted into `app/src/main/python/kiyaa_music.py`:
- `ytmusicapi` song search (`filter="songs"`, limit 25)
- `yt-dlp` Python API to extract a direct audio URL
- best-effort lyrics lookup, retaining the original `get_lyrics(video_id)` call

Chaquopy packages Python and its dependencies into the Android app. Media3 ExoPlayer/MediaSession handles audio playback and background media controls.

## Build
Open this repository in GitHub and use **Actions → Build KiyaaPayy APK**. The workflow uploads `KiyaaPayy-debug-apk` as an artifact.

## Important technical limitations
1. YouTube/YouTube Music extraction is unofficial and can break when upstream changes. `yt-dlp` may need updates.
2. Lyrics are best-effort: `ytmusicapi.get_lyrics()` may require a lyrics browse ID, not a video ID. If unavailable, the app shows a clean unavailable message.
3. This first embedded-native implementation establishes real search, stream extraction, and Media3 playback, but persistence, full queue/shuffle/repeat UI, playlist editing, and robust lyrics browse-id resolution are not complete yet.
4. The Python dependencies are packaged into the APK at build time; the first build can take several minutes and needs internet access in GitHub Actions.
5. Use only for personal listening and respect the applicable service terms and copyright rules.

## Project layout
- `app/src/main/java/com/kiyaapay/` — native Android UI, repository bridge, MediaSession playback service
- `app/src/main/python/kiyaa_music.py` — embedded Python provider adapted from `server.py`
- `.github/workflows/build-apk.yml` — cloud APK build
